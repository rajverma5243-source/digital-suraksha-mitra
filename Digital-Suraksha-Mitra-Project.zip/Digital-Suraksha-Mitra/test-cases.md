# Test Cases — Digital Suraksha Mitra

| ID | Test | Steps | Expected result |
|---|---|---|---|
| TC-01 | Initial page load | Open `index.html` in a modern browser | Hero, learning cards, checklist, quiz and help section render without errors |
| TC-02 | Navigation on desktop | Click each header navigation link | Browser scrolls to the corresponding section |
| TC-03 | Mobile menu | Use a narrow/mobile viewport; tap menu icon twice | Navigation opens, then closes; `aria-expanded` updates |
| TC-04 | Learning dialog | Click “और जानें” on a learning card | Dialog shows the matching card title and safety explanation |
| TC-05 | Close dialog | Open a dialog and click “समझ गया” or × | Dialog closes |
| TC-06 | Checklist progress | Check and uncheck checklist items | Progress bar and completion count update accurately |
| TC-07 | Checklist persistence | Check an item, reload page | Item remains checked in the same browser |
| TC-08 | Quiz correct answer | Select the correct option | Correct option is highlighted, explanation appears, score increments |
| TC-09 | Quiz incorrect answer | Select a wrong option | Wrong and correct choices are highlighted; score does not increment |
| TC-10 | Quiz completion | Answer all five questions | Final score and completion feedback are shown |
| TC-11 | Quiz restart | Click “फिर से शुरू करें” | Quiz returns to question 1 and score resets to zero |
| TC-12 | Reporting link | Click National Cyber Crime Reporting Portal link | Official portal opens in a new tab |
| TC-13 | Responsive layout | Test at mobile, tablet and desktop widths | Content remains readable with no horizontal overflow |
| TC-14 | Offline behavior | Disable network and reload (fonts may be unavailable) | Core content and interactions continue to work |

## Sample quiz data
The quiz covers OTP secrecy, UPI PIN use, phishing links, strong passwords, and trusted app sources.
