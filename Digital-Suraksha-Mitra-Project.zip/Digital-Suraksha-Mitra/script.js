const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
navLinks.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  navLinks.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

const checklistInputs = [...document.querySelectorAll('#checklistItems input')];
function updateChecklist() {
  const done = checklistInputs.filter(input => input.checked).length;
  document.getElementById('progressBar').style.width = `${done / checklistInputs.length * 100}%`;
  document.getElementById('progressText').textContent = `${done} में से ${checklistInputs.length} पूरे`;
  localStorage.setItem('dsm-checklist', JSON.stringify(checklistInputs.map(input => input.checked)));
}
try {
  const saved = JSON.parse(localStorage.getItem('dsm-checklist') || '[]');
  checklistInputs.forEach((input, i) => input.checked = Boolean(saved[i]));
} catch (_) {}
checklistInputs.forEach(input => input.addEventListener('change', updateChecklist));
updateChecklist();

const dialog = document.getElementById('tipDialog');
document.querySelectorAll('.learn-more').forEach(button => button.addEventListener('click', () => {
  document.getElementById('tipBody').textContent = button.dataset.tip;
  document.getElementById('tipTitle').textContent = button.closest('.topic-card').querySelector('h3').textContent;
  dialog.showModal();
}));
function closeTip() { dialog.close(); }
document.getElementById('closeDialog').addEventListener('click', closeTip);
document.getElementById('doneDialog').addEventListener('click', closeTip);

const questions = [
  {q:'अगर कोई कॉल करके OTP माँगे तो क्या करेंगे?', a:['उसे OTP बता देंगे','कॉल काटकर OTP गुप्त रखेंगे','OTP मैसेज आगे भेज देंगे','उसका स्क्रीनशॉट भेजेंगे'], correct:1, explain:'बिल्कुल सही! OTP किसी के साथ साझा न करें—बैंक या सपोर्ट कर्मचारी भी इसे नहीं माँगना चाहिए।'},
  {q:'पैसे पाने के लिए UPI PIN डालना जरूरी है?', a:['हाँ, हमेशा','सिर्फ रात में','नहीं, PIN भुगतान करने के लिए होता है','अगर सामने वाला कहे तो'], correct:2, explain:'सही! UPI PIN भुगतान अधिकृत करता है। पैसे प्राप्त करने के लिए PIN डालने की जरूरत नहीं होती।'},
  {q:'अनजान संदेश में “अभी क्लिक करें वरना अकाउंट बंद” लिखा है। क्या करें?', a:['तुरंत क्लिक करें','संदेश में दिए नंबर पर कॉल करें','लिंक पर पासवर्ड डालें','आधिकारिक ऐप/वेबसाइट से सत्यापित करें'], correct:3, explain:'सही! डर या जल्दबाज़ी पैदा करने वाले संदेश फिशिंग हो सकते हैं। आधिकारिक माध्यम से जाँचें।'},
  {q:'सबसे सुरक्षित पासवर्ड कौन-सा है?', a:['12345678','अपना नाम और जन्मवर्ष','लंबा, अनोखा पासफ्रेज़','हर जगह एक ही पासवर्ड'], correct:2, explain:'सही! हर अकाउंट के लिए अलग और लंबा पासवर्ड रखें। पासवर्ड मैनेजर मदद कर सकता है।'},
  {q:'ऐप कहाँ से इंस्टॉल करना बेहतर है?', a:['किसी भी लिंक से','भरोसेमंद आधिकारिक ऐप स्टोर से','अनजान APK वेबसाइट से','मैसेज में आई फाइल से'], correct:1, explain:'सही! आधिकारिक ऐप स्टोर का उपयोग करें और इंस्टॉल करने से पहले ऐप की जानकारी व permissions जाँचें।'}
];
let questionIndex = 0, score = 0, answered = false;
const questionText = document.getElementById('questionText');
const answersEl = document.getElementById('answers');
const feedback = document.getElementById('feedback');
const nextButton = document.getElementById('nextQuestion');
function renderQuestion() {
  const item = questions[questionIndex];
  answered = false;
  document.getElementById('questionCount').textContent = `प्रश्न ${questionIndex + 1} / ${questions.length}`;
  document.getElementById('scoreBadge').textContent = `स्कोर: ${score}`;
  document.getElementById('quizProgress').style.width = `${questionIndex / questions.length * 100}%`;
  questionText.textContent = item.q;
  answersEl.innerHTML = '';
  feedback.textContent = '';
  feedback.className = 'feedback';
  nextButton.disabled = true;
  nextButton.textContent = questionIndex === questions.length - 1 ? 'परिणाम देखें →' : 'अगला प्रश्न →';
  item.a.forEach((answer, i) => {
    const button = document.createElement('button');
    button.className = 'answer';
    const letter = document.createElement('span'); letter.className = 'letter'; letter.textContent = String.fromCharCode(65 + i);
    const text = document.createElement('span'); text.textContent = answer;
    button.append(letter, text);
    button.addEventListener('click', () => selectAnswer(i));
    answersEl.appendChild(button);
  });
}
function selectAnswer(selected) {
  if (answered) return;
  answered = true;
  const item = questions[questionIndex];
  [...answersEl.children].forEach((button, i) => {
    button.disabled = true;
    if (i === item.correct) button.classList.add('correct');
    else if (i === selected) button.classList.add('wrong');
  });
  if (selected === item.correct) {
    score++;
    feedback.textContent = item.explain;
    feedback.classList.add('good');
  } else {
    feedback.textContent = `यह सही विकल्प नहीं है। ${item.explain}`;
    feedback.classList.add('bad');
  }
  document.getElementById('scoreBadge').textContent = `स्कोर: ${score}`;
  document.getElementById('quizProgress').style.width = `${(questionIndex + 1) / questions.length * 100}%`;
  nextButton.disabled = false;
}
nextButton.addEventListener('click', () => {
  if (!answered) return;
  if (questionIndex < questions.length - 1) { questionIndex++; renderQuestion(); }
  else {
    questionText.textContent = `क्विज़ पूरा हुआ! आपका स्कोर ${score}/${questions.length} है।`;
    answersEl.innerHTML = '';
    feedback.textContent = score === questions.length ? 'शानदार! आप साइबर सुरक्षा की अच्छी आदतें जानते हैं।' : 'अच्छा प्रयास! सुरक्षा टिप्स दोबारा पढ़ें और फिर से कोशिश करें।';
    feedback.className = 'feedback good';
    document.getElementById('questionCount').textContent = 'परिणाम';
    document.getElementById('quizProgress').style.width = '100%';
    nextButton.disabled = true;
    nextButton.textContent = 'क्विज़ पूरा हुआ';
  }
});
document.getElementById('restartQuiz').addEventListener('click', () => { questionIndex = 0; score = 0; renderQuestion(); });
renderQuestion();
