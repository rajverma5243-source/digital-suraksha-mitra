# Digital Suraksha Mitra 🛡️

A responsive, Hindi-first educational web prototype that teaches practical cyber-safety habits through learning cards, a personal safety checklist, and an interactive quiz.

## Features
- Responsive layout for mobile and desktop
- Cyber-safety topics: phishing, passwords, device security, and UPI payments
- Interactive “learn more” dialogs
- Safety checklist with progress saved in browser `localStorage`
- Five-question quiz with instant feedback, score, and restart
- Official India National Cyber Crime Reporting Portal link and helpline 1930
- No backend, account, API key, or build step required

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Internet is only needed to load the optional Google Fonts; the application itself runs locally.

Optional local server:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

## Project structure
- `index.html` — page content and accessible semantic structure
- `style.css` — responsive visual styling
- `script.js` — navigation, checklist persistence, dialogs, and quiz logic
- `ARCHITECTURE.md` — design and data-flow notes
- `test-cases.md` — manual test cases
- `LICENSE` — MIT license

## Deployment to GitHub Pages
1. Create a new **public** repository on GitHub, for example `digital-suraksha-mitra`.
2. Upload the files in this folder (not just the ZIP file).
3. Open repository **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for deployment. The site URL will look like `https://YOUR-USERNAME.github.io/digital-suraksha-mitra/`.
6. For the MyBharat “Repository URL” field, use the repository URL: `https://github.com/YOUR-USERNAME/digital-suraksha-mitra` — not the Pages website URL.

Replace `YOUR-USERNAME` with your actual GitHub username. Verify that the repository contains all source files before submitting.

## Important note
This is an independent educational prototype, not an official Government of India website and not a replacement for professional or official cybercrime assistance. The reporting link points to `https://cybercrime.gov.in/`.
