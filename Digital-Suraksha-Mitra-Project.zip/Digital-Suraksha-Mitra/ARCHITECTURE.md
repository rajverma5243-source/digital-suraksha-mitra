# Technical Design Document — Digital Suraksha Mitra

## 1. Overview
A static, client-side educational website. It uses semantic HTML for content, CSS for layout and responsive styling, and vanilla JavaScript for interactive behavior. There is no server-side component and no personal data is sent to a backend.

## 2. High-level architecture
```text
User / Browser
     |
     +--> index.html (content and semantic structure)
     |
     +--> style.css (responsive presentation)
     |
     +--> script.js
              +--> Navigation menu
              +--> Learning-tip dialog
              +--> Safety checklist --> browser localStorage
              +--> Quiz state (in memory)
     |
     +--> External official reporting portal (user-initiated link)
```

## 3. Components
- **Learning cards:** Each card contains a short safety summary and a `data-tip` attribute. JavaScript places the selected tip into an accessible dialog.
- **Checklist:** Five checkboxes update the completion count and progress bar. Checkbox state is stored in localStorage on the current browser/device.
- **Quiz:** Five static question objects contain answer choices, correct index, and explanation. State (`questionIndex`, `score`, `answered`) exists only while the page is open.
- **Help section:** Links to the official National Cyber Crime Reporting Portal and phone link `1930`.

## 4. Data and privacy
- No user registration or analytics.
- No form submissions and no personal information collection.
- Checklist preferences are saved locally in the browser under `dsm-checklist`. Clearing site data removes them.
- Quiz answers and score are not transmitted or persisted.
- Google Fonts may make a network request; the page otherwise works without a backend.

## 5. Security considerations
- External reporting link opens in a new tab with `rel="noopener noreferrer"`.
- Quiz answer labels are inserted using `textContent` where dynamic text is used.
- No secrets, tokens, or API keys are present.
- Production improvements could include a restrictive Content Security Policy, self-hosted fonts, automated accessibility checks, and cross-browser testing.

## 6. Technology stack
HTML5, CSS3, vanilla JavaScript (ES6), browser localStorage. No package manager or compilation is required.
